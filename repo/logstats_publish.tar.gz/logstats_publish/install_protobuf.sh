cd protobuf
echo "install protobuf..."
tar zxvf protobuf-2.5.0.tar.gz
cd protobuf-2.5.0
./configure
make
make install
cd ..
echo "install protobuf-c..."
tar zxvf autoconf-2.64.tar.gz
cd autoconf-2.64
./configure
make
make install
cd ..
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig/:/usr/local/lib:$PKG_CONFIG_PATH 
tar zxvf protobuf-c-1.0.0.tar.gz
export PATH=/usr/local/bin:$PATH
cd protobuf-c-1.0.0
./autogen.sh
./configure
make
make install
cd ..

echo "install setuptools..."
tar zxvf setuptools-15.2.tar.gz
cd setuptools-15.2
python setup.py install
cd ..
echo "install tornado..."
tar zxvf tornado-2.3.tar.gz
cd tornado-2.3
python setup.py install
cd ..
echo "install protobuf.egg..."
easy_install protobuf-2.4.1-py2.6.egg

